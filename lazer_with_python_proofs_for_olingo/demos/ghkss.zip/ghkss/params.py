from math import sqrt

vname = "params"

# q_small = 2101003516513793

deg = 256
mod = 633544653872304603170707504554316801
# mod = 12289
dim = (2, 2)
wpart = [[0], [1]]
# wl2 = wl2 = [q_small * sqrt(deg), 1]
wl2 = wl2 = [sqrt(deg), 1]
wbin = [0, 0]
